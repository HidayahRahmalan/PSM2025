- 1.0.0
    - No changes

- 1.0.0-beta1
    - Implemented Bloom Filter
    - Added Boolean Array
    - Added `insert` method
    - Simplify false positive rate calculation
