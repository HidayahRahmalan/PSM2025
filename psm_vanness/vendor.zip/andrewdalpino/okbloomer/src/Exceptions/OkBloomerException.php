<?php

namespace OkBloomer\Exceptions;

use Throwable;

interface OkBloomerException extends Throwable
{
    //
}
