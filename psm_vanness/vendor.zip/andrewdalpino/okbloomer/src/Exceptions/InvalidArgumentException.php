<?php

namespace OkBloomer\Exceptions;

use InvalidArgumentException as SplInvalidArgumentException;

class InvalidArgumentException extends SplInvalidArgumentException implements OkBloomerException
{
    //
}
