<?php

namespace Amp\Process;

class ProcessException extends \Exception
{
}
