<?php

namespace Amp\Parallel\Context;

class ContextException extends \Exception
{
}
