<?php

namespace Amp\Parallel\Worker;

class WorkerException extends \Exception
{
}
