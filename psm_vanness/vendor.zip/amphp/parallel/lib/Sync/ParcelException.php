<?php

namespace Amp\Parallel\Sync;

class ParcelException extends \Exception
{
}
