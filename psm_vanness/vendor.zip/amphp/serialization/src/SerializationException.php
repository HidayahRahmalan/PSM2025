<?php

namespace Amp\Serialization;

class SerializationException extends \Exception
{
}
