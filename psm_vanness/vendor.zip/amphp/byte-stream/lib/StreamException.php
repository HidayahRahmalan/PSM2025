<?php

namespace Amp\ByteStream;

class StreamException extends \Exception
{
}
