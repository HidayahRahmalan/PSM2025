<!---
name: 🐞 Failing Test
about: You found a bug and have a failing test?
labels: bug, tests
--->

<!--
- Please do not send a pull request for an issue in a version of ZipStream-PHP
  that is no longer supported.
  See: https://github.com/maennchen/ZipStream-PHP#version-support
- Please target the oldest branch of ZipStream-PHP that is still supported and
  where the test fails.
-->
